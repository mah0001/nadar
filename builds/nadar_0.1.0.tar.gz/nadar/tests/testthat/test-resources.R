
context("Add new external resources")

test_that("Add External Resources to a study",{
  resource_file_path='/Users/m2/Downloads/output-digital-library_OD.xlsx'
  result=nadar::resource_create(
          idno="testing-09090",
          dctype="[doc/adm]",
          dcformat="application/excel",
          title="document title",
          author="author name",
          file_path=resource_file_path
          )
  print(result)
  expect_type( result,"list")
})
