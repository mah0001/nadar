library(testthat)
nadar::set_api_key("9b69026dcaa2f952a6a1ee9948283417")
nadar::set_api_url("http://localhost:8080/nada_data_api/index.php/api")
nadar::set_verbose(FALSE)

test_check("nadar")
