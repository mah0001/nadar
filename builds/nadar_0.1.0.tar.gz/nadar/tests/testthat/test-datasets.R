context("Get datasets")
test_that("Listing datasets",{
  result=nadar::datasets()
  expect_type(result,'list')
})


context("Upload datasets using API")

test_that("Creating dataset",{

  doc_desc=list(
    "idno"="doc-idno-xyxyx",
    "producers"=list(
      list(
        "name"="name here",
        "abbr"="abbreviation"
      )
    )
  )

  study_desc=list(
    "title_statement"= list(
      "idno"= "study-idno-test-2",
      "title"= "string",
      "sub_title"= "string",
      "alternate_title"= "string",
      "translated_title"= "string"
    ),
    "study_info"=list(
      "nation"=list(
        list(
          "name"="Test",
          "abbreviation"="tst")
      )
    )
  )

  result=nadar::create_survey (
    idno="testing3xs",
    published = 1,
    overwrite = "yes",
    doc_desc = doc_desc,
    study_desc = study_desc,
    data_files=NULL,
    variables=NULL,
    variable_groups = NULL,
    additional = NULL
  )
  expect_type( result,"list")
})

context("Import DDI file")

test_that("Import DDI",{
  xml_file_path='examples/AFR_1996_WDAAF_v01_M.xml'
  result=nadar::import_ddi(xml_file=xml_file_path,published = 1,overwrite = "yes")
  print(result)
  expect_equal( result$status_code,200)
})



context("External resources")

test_that("List external resources",{
  resources=nadar::resources(dataset_idno="INDSTAT4_ISIC4_V1")
  typeof(resources)
  expect_type( resources,"list")
})


context("Download external resources")

test_that("Download external resource file",{
  resource=nadar::resource_download(dataset_idno="INDSTAT4_ISIC4_V1", resource_id=273)
  print(resource)
  expect_type( resource,"list")
})



context("Create new dataset of type Document")

test_that("Creating Document",{

  metadata=list(
    "metadata_information"= list(
      "title"= "string",
      "idno"= "string",
      "producers"= list(
        list(
          "name"= "string",
          "abbr"= "string",
          "affiliation"= "string",
          "role"= "string"
        )
        ),
      "production_date"= "string",
      "version"= "string"
    ),
    "document_description"= list(
      "title_statement"= list(
        "idno"= "document-unique-id",
        "title"= "document title",
        "sub_title"= "string",
        "alternate_title"= "string",
        "abbreviated_title"= "string"
      ),
      "type"= "article",
      "description"= "string",
      "toc"= "string",
      "toc_structured"= list(
        list(
          "id"= "string",
          "parent_id"= "string",
          "name"= "string"
        )
        ),
      "abstract"= "string",
      "notes"= list(
        list(
          "note"= "string"
        )
        ),
      "scope"= "string",
      "ref_country"= list(
        list(
          "name"= "country name",
          "code"= "string"
        ),
        list(
          "name"= "country name 2",
          "code"= "string"
        )
        ),
      "spatial_coverage"= "string",
      "temporal_coverage"= "string",
      "date_created"= "string",
      "date_available"= "string",
      "date_modified"= "string",
      "date_published"= "string",
      "id_numbers"= list(
        "type"= "string",
        "value"= "string"
      ),
      "publication_frequency"= "string",
      "languages"= list(
        list(
          "name"= "string",
          "code"= "string"
        )
        ),
      "license"= list(
        list(
          "name"= "string",
          "uri"= "string"
        )
        ),
      "bibliographic_citation"= "string",
      "chapter"= "string",
      "edition"= "string",
      "institution"= "string",
      "journal"= "string",
      "volume"= "string",
      "issue"= "string",
      "pages"= "string",
      "series"= "string",
      "creator"= "string",
      "authors"= list(
        list(
          "first_name"= "string",
          "initial"= "string",
          "last_name"= "string",
          "affiliation"= "string"
        )
        ),
      "editors"= list(
        list(
          "first_name"= "string",
          "initial"= "string",
          "last_name"= "string",
          "affiliation"= "string"
        )
        ),
      "translators"= list(
        list(
          "first_name"= "string",
          "initial"= "string",
          "last_name"= "string",
          "affiliation"= "string"
        )
        ),
      "contributors"= list(
        list(
          "first_name"= "string",
          "initial"= "string",
          "last_name"= "string",
          "affiliation"= "string"
        )
        ),
      "publisher"= "string",
      "publisher_address"= "string",
      "rights"= "string",
      "copyright"= "string",
      "usage_terms"= "string",
      "security_classification"= "string",
      "access_restrictions"= "string",
      "sources"= list(
        "data_source"= list(),
        "source_origin"= "string",
        "source_char"= "string",
        "source_doc"= "string"
      ),
      "keywords"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
        ),
      "themes"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
        ),
      "topics"= list(
        list(
          "id"= "string",
          "name"= "string",
          "parent_id"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
        ),
      "disciplines"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
        ),
      "audience"= "string",
      "mandate"= "string",
      "pricing"= "string",
      "relations"= list(
        list(
          "name"= "string",
          "type"= "isPartOf"
        )
        ),
      "lda_topics"= list(
        list(
          "model_info"= list(
            list(
              "source"= "string",
              "author"= "string",
              "version"= "string",
              "model_id"= "string",
              "nb_topics"= 0,
              "description"= "string",
              "corpus"= "string",
              "uri"= "string"
            )
            ),
          "topic_description"= list(
            list(
              "topic_id"= 1,
              "topic_score"= .01,
              "topic_label"= "label",
              "topic_words"= list(
                list(
                  "word"= "string"
                )
              )
            )
          )
        )
      )
    ),
    "tags"= list(
      list(
        "tag"= "string"
      )
      ),
    "files"= list(
      list(
        "file_uri"= "string",
        "format"= "string",
        "location"= "string",
        "note"= "string"
      )
    )
  )


  tryCatch({

    result=nadar::create_document (
      idno="testing",
      published = 1,
      overwrite = "no",
      access_policy = "open",
      data_remote_url = NULL,
      metadata= metadata
    )

    expect_equal(result$status_code,200)

  }, error = function(e) {
    print ("------ ERROR ----")
    print(e)
  }, finally={
    print("closing....")
  })


})



context("Upload thumbnail")

test_that("Upload a thumbnail for a study",{
  result=nadar::upload_thumbnail(
              idno="document-unique-id",
              thumbnail="survey-thumb.png")
  print(result)
  expect_equal(result$status_code,200)
})


context("Find study by IDNO")

test_that("Find study by IDNO",{
  result=nadar::find_by_idno(idno="document-unique-id")
  expect_equal(result$status_code,200)
})

test_that("Look for a non-existent study IDNO",{
  result=nadar::find_by_idno(idno="document-unique-id-x")
  expect_equal(result$status_code,400)
})

