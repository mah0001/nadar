context("Timeseries")

context("Create new timeseries indicator")

test_that("Creating Timeseries",{

  metadata=list(
    "metadata_creation"= list(
      "producers"= list(
        list(
          "name"= "string",
          "abbr"= "string",
          "affiliation"= "string",
          "role"= "string"
        )
      ),
      "prod_date"= "string",
      "version"= "string"
    ),
    "series_description"= list(
      "idno"= "timeseries-unique-idno",
      "name"= "Series name",
      "database_id"= "string",
      "aliases"= list(
        list(
          "alias"= "string"
        )
      ),
      "measurement_unit"= "string",
      "periodicity"= "string",
      "base_period"= "string",
      "definition_short"= "string",
      "definition_long"= "string",
      "definition_references"= list(
        list(
          "source"= "string",
          "uri"= "string",
          "note"= "string"
        )
      ),
      "statistical_concept"= "string",
      "concepts"= list(
        list(
          "name"= "string",
          "definition"= "string",
          "uri"= "string"
        )
      ),
      "methodology"= "string",
      "imputation"= "string",
      "quality_checks"= "string",
      "quality_note"= "string",
      "series_break"= "string",
      "limitation"= "string",
      "themes"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
      ),
      "topics"= list(
        list(
          "id"= "string",
          "name"= "string",
          "parent_id"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
      ),
      "disciplines"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
      ),
      "relevance"= "string",
      "time_periods"= list(
        list(
          "start"= "string",
          "end"= "string"
        )
      ),
      "geographic_units"= list(
        list(
          "name"= "string",
          "code"= "string",
          "type"= "string"
        )
      ),
      "aggregation_method"= "string",
      "license"= list(
        "name"= "string",
        "uri"= "string"
      ),
      "confidentiality"= "string",
      "confidentiality_status"= "string",
      "confidentiality_note"= "string",
      "links"= list(
        list(
          "type"= "string",
          "description"= "string",
          "uri"= "string"
        )
      ),
      "api_documentation"= list(
        "description"= "string",
        "uri"= "string"
      ),
      "source"= "string",
      "source_note"= "string",
      "keywords"= list(
        list(
          "name"= "string",
          "vocabulary"= "string",
          "uri"= "string"
        )
      ),
      "acronyms"= list(
        list(
          "acronym"= "string",
          "expansion"= "string",
          "occurrence"= 0
        )
      ),
      "notes"= list(
        list(
          "note"= "string"
        )
      ),
      "related_indicators"= list(
        list(
          "code"= "string",
          "label"= "string",
          "uri"= "string"
        )
      ),
      "compliance"= list(
        list(
          "standard"= "string",
          "organization"= "string",
          "uri"= "string"
        )
      ),
      "lda_topics"= list(
        list(
          "model_info"= list(
            list(
              "source"= "string",
              "author"= "string",
              "version"= "string",
              "model_id"= "string",
              "nb_topics"= 0,
              "description"= "string",
              "corpus"= "string",
              "uri"= "string"
            )
          ),
          "topic_description"= list(
            list(
              "topic_id"= 1,
              "topic_score"= 0.0002,
              "topic_label"= "string",
              "topic_words"= list(
                list(
                  "word"= "string",
                  "word_weight"= 0
                )
              )
            )
          )
        )
      ),
      "word_vectors"= list(
        list(
          "id"= "string",
          "description"= "string",
          "date"= "string",
          "vector"= list(0.526272732298821,0.587750827893615)
        )
      ),
      "series_groups"= list(
        list(
          "name"= "string",
          "version"= "string",
          "uri"= "string"
        )
      )
    ),
    "additional"= list()
  )


  tryCatch({

    result=nadar::create_timeseries (
      idno="testing",
      published = 1,
      overwrite = "no",
      access_policy = "open",
      data_remote_url = NULL,
      metadata= metadata
    )

    expect_equal(result$status_code,200)

  }, error = function(e) {
    print ("------ ERROR ----")
    print(e)
  }, finally={
    print("closing....")
  })


})
