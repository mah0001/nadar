context("Timeseries")
nadar::set_api_key("9b69026dcaa2f952a6a1ee9948283417")
nadar::set_api_url("http://localhost:8080/nada_data_api/index.php/api")
nadar::set_verbose(TRUE)



context("Create new timeseries database")

test_that("Creating Timeseries database",{

  metadata={
    "published": 0,
    "overwrite": "no",
    "database_description": {
      "title_statement": {
        "idno": "string",
        "title": "string",
        "sub_title": "string",
        "alternate_title": "string",
        "translated_title": "string"
      },
      "authoring_entity": [
        {
          "name": "string",
          "role": "string",
          "affiliation": "string",
          "abbreviation": null,
          "email": null
        }
        ],
      "abstract": "string",
      "url": "string",
      "type": "string",
      "doi": "string",
      "date_created": "string",
      "date_published": "string",
      "version": [
        {
          "version": "string",
          "date": "string",
          "responsibility": "string",
          "notes": "string"
        }
        ],
      "update_frequency": "string",
      "update_schedule": [
        {
          "update": "string"
        }
        ],
      "time_coverage": [
        {
          "start": "string",
          "end": "string"
        }
        ],
      "time_coverage_note": "string",
      "periodicity": [
        {
          "period": "string"
        }
        ],
      "themes": [
        {
          "name": "string",
          "vocabulary": "string",
          "uri": "string"
        }
        ],
      "topics": [
        {
          "id": "string",
          "name": "string",
          "parent_id": "string",
          "vocabulary": "string",
          "uri": "string"
        }
        ],
      "keywords": [
        {
          "name": "string",
          "vocabulary": "string",
          "uri": "string"
        }
        ],
      "geographic_units": [
        {
          "name": "string",
          "code": "string",
          "type": "string"
        }
        ],
      "geographic_coverage_note": "string",
      "bbox": [
        {
          "west": "string",
          "east": "string",
          "south": "string",
          "north": "string"
        }
        ],
      "geographic_granularity": "string",
      "geographic_area_count": "string",
      "sponsors": [
        {
          "name": "string",
          "abbreviation": "string",
          "role": "string",
          "grant": "string",
          "uri": "string"
        }
        ],
      "acknowledgments": [
        {
          "name": "string",
          "affiliation": "string",
          "role": "string",
          "uri": "string"
        }
        ],
      "contacts": [
        {
          "name": "string",
          "role": "string",
          "affiliation": "string",
          "email": "string",
          "telephone": "string",
          "uri": "string"
        }
        ],
      "links": [
        {
          "uri": "string",
          "description": "string"
        }
        ],
      "languages": [
        {
          "name": "string",
          "code": "string"
        }
        ],
      "access_options": [
        {
          "type": "string",
          "uri": "string",
          "note": "string"
        }
        ],
      "license": [
        {
          "type": "string",
          "uri": "string",
          "note": "string"
        }
        ],
      "citation": "string",
      "notes": [
        {
          "note": "string"
        }
        ],
      "disclaimer": "string",
      "copyright": "string"
    },
    "additional": {}
  }


  tryCatch({

    result=nadar::create_timeseries_db (
      idno="testing",
      published = 1,
      overwrite = "no",
      metadata= metadata
    )

    expect_equal(result$status_code,200)

  }, error = function(e) {
    print ("------ ERROR ----")
    print(e)
  }, finally={
    print("closing....")
  })


})
